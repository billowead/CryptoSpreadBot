import asyncio
import ccxt.async_support as ccxt
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

# Вставьте сюда токен вашего Telegram-бота
TOKEN = "ВАШ_TELEGRAM_TOKEN"
# Вставьте сюда ваш chat_id (ID пользователя или канала), например: "123456789"
CHAT_ID = "ВАШ_CHAT_ID"

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

# Пары, которые мониторим
pairs = [
    "BTC/USDT", "ETH/USDT", "BNB/USDT", "XRP/USDT",
    "SOL/USDT", "DOGE/USDT", "MATIC/USDT", "ADA/USDT",
    "LTC/USDT", "AVAX/USDT", "DOT/USDT", "UNI/USDT",
    "LINK/USDT", "TRX/USDT", "APT/USDT"
]

# Биржи для сравнения
exchange_names = [
    "binance", "kraken", "coinbasepro", "bitfinex",
    "huobipro", "bitstamp", "poloniex", "kucoin"
]

# Порог спреда в процентах
SPREAD_THRESHOLD = 2.0

async def fetch_prices():
    prices = {}
    for name in exchange_names:
        exchange = getattr(ccxt, name)()
        prices[name] = {}
        for pair in pairs:
            try:
                ticker = await exchange.fetch_ticker(pair)
                prices[name][pair] = ticker['last']
            except Exception:
                prices[name][pair] = None
        await exchange.close()
    return prices

async def check_spreads():
    prices = await fetch_prices()
    alerts = []
    for pair in pairs:
        valid_prices = [
            (ex, prices[ex][pair])
            for ex in exchange_names
            if prices[ex].get(pair) is not None
        ]
        if len(valid_prices) < 2:
            continue
        max_ex, max_price = max(valid_prices, key=lambda x: x[1])
        min_ex, min_price = min(valid_prices, key=lambda x: x[1])
        spread = (max_price - min_price) / min_price * 100
        if spread >= SPREAD_THRESHOLD:
            alerts.append(
                f"Спред для {pair}:
"
                f"{min_ex}: {min_price}$
"
                f"{max_ex}: {max_price}$
"
                f"Разница: {spread:.2f}%"
            )
    return alerts

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer(
        "Привет! Я буду уведомлять тебя о выгодных спредах между криптобиржами (от 2%). Просто жди сообщений!"
    )

async def periodic_check():
    await bot.wait_until_ready()
    while True:
        alerts = await check_spreads()
        for alert in alerts:
            await bot.send_message(chat_id=CHAT_ID, text=alert)
        await asyncio.sleep(60)

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.create_task(periodic_check())
    executor.start_polling(dp, skip_updates=True)
